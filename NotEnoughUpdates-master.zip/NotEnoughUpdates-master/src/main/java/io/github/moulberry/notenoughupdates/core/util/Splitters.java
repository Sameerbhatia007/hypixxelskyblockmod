package io.github.moulberry.notenoughupdates.core.util;

import com.google.common.base.Splitter;

public class Splitters {

    public static final Splitter NEWLINE_SPLITTER = Splitter.on('\n');


}
