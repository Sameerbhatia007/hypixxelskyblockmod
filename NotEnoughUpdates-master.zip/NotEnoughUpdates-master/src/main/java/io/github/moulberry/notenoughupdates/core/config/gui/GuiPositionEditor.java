package io.github.moulberry.notenoughupdates.core.config.gui;

import io.github.moulberry.notenoughupdates.core.config.Position;
import io.github.moulberry.notenoughupdates.core.util.render.RenderUtils;
import io.github.moulberry.notenoughupdates.util.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

import java.io.IOException;

public class GuiPositionEditor extends GuiScreen {

    private Position position;
    private Position originalPosition;
    private int elementWidth;
    private int elementHeight;
    private Runnable renderCallback;
    private Runnable positionChangedCallback;
    private Runnable closedCallback;
    private boolean clicked = false;
    private int grabbedX = 0;
    private int grabbedY = 0;

    private int oldMouseX = 0;
    private int oldMouseY = 0;

    private int guiScaleOverride = -1;

    public GuiPositionEditor(Position position, int elementWidth, int elementHeight,
                                    Runnable renderCallback,
                                    Runnable positionChangedCallback,
                                    Runnable closedCallback) {
        this.position = position;
        this.originalPosition = position.clone();
        this.elementWidth = elementWidth;
        this.elementHeight = elementHeight;
        this.renderCallback = renderCallback;
        this.positionChangedCallback = positionChangedCallback;
        this.closedCallback = closedCallback;
    }

    public GuiPositionEditor withScale(int scale) {
        this.guiScaleOverride = scale;
        return this;
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        closedCallback.run();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
        ScaledResolution scaledResolution;
        if(guiScaleOverride >= 0) {
            scaledResolution = Utils.pushGuiScale(guiScaleOverride);
        } else {
            scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        }


        this.width = scaledResolution.getScaledWidth();
        this.height = scaledResolution.getScaledHeight();
        mouseX = Mouse.getX() * width / Minecraft.getMinecraft().displayWidth;
        mouseY = height - Mouse.getY() * height / Minecraft.getMinecraft().displayHeight - 1;

        drawDefaultBackground();

        if(clicked) {
            grabbedX += position.moveX(mouseX - grabbedX, elementWidth, scaledResolution);
            grabbedY += position.moveY(mouseY - grabbedY, elementHeight, scaledResolution);
        }

        renderCallback.run();

        int x = position.getAbsX(scaledResolution);
        int y = position.getAbsY(scaledResolution);

        if(position.isCenterX()) x -= elementWidth/2;
        if(position.isCenterY()) y -= elementHeight/2;
        Gui.drawRect(x, y, x+elementWidth, y+elementHeight, 0x80404040);

        if(guiScaleOverride >= 0) {
            Utils.pushGuiScale(-1);
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);

        if(mouseButton == 0) {
            ScaledResolution scaledResolution;
            if(guiScaleOverride >= 0) {
                scaledResolution = Utils.pushGuiScale(guiScaleOverride);
            } else {
                scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
            }
            mouseX = Mouse.getX() * width / Minecraft.getMinecraft().displayWidth;
            mouseY = height - Mouse.getY() * height / Minecraft.getMinecraft().displayHeight - 1;

            int x = position.getAbsX(scaledResolution);
            int y = position.getAbsY(scaledResolution);
            if(position.isCenterX()) x -= elementWidth/2;
            if(position.isCenterY()) y -= elementHeight/2;

            if(mouseX >= x && mouseY >= y &&
                    mouseX <= x+elementWidth && mouseY <= y+elementHeight) {
                clicked = true;
                grabbedX = mouseX;
                grabbedY = mouseY;
            }

            if(guiScaleOverride >= 0) {
                Utils.pushGuiScale(-1);
            }
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        clicked = false;
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        super.mouseClickMove(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);

        if(clicked) {
            ScaledResolution scaledResolution;
            if(guiScaleOverride >= 0) {
                scaledResolution = Utils.pushGuiScale(guiScaleOverride);
            } else {
                scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
            }
            mouseX = Mouse.getX() * width / Minecraft.getMinecraft().displayWidth;
            mouseY = height - Mouse.getY() * height / Minecraft.getMinecraft().displayHeight - 1;

            oldMouseX = mouseX;
            oldMouseY = mouseY;

            grabbedX += position.moveX(mouseX - grabbedX, elementWidth, scaledResolution);
            grabbedY += position.moveY(mouseY - grabbedY, elementHeight, scaledResolution);
            positionChangedCallback.run();

            if(guiScaleOverride >= 0) {
                Utils.pushGuiScale(-1);
            }
        }
    }
}
